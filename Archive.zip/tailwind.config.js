const colors = require("tailwindcss/colors");
module.exports = {
  purge: [],
  darkMode: false, // or 'media' or 'class'
  theme: {
    container: {
      center: true,
      padding: '1rem !important',
    },
    colors: {
      ...colors,
    },
    customForms: theme => ({
      default: {
        checkbox: {
          icon: iconColor => `<svg fill="${iconColor}" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg" ><path d="M0 11l2-2 5 5L18 3l2 2L7 18z"/></svg>`,
          iconColor: theme('colors.green.556'),
          '&:hover': {
            iconColor: theme('colors.gray.700'),
          }
        },
      }
    }),
    extend: {
      colors: {
        'primary1': '#374053',
        'primary2': '#C0C3C9',
        'secondary1': '#969CAA',
        'secondary2': '#F4F5F6',
        'green-556': '#5cd5c4',
        'gray-111': '#f5f5f5',
        'gray-112': '#fcfcfc',
        'reed-301': 'rgba(245,81,87,.2)',
        'reed-302': '#f55157',
        'gray-557': '#888',
        'dark-green': '#49ada0',
        'dark-brown': 'rgb(82 82 82)',
      },
      width: {
        "95-px": "95px",
        "70-px": "70px",
        "350-px": "350px",
        "500-px": "500px",
        "600-px": "600px",
        "800-px": "800px",
      },
      maxHeight: {
        "95-px": "95px",
        "70-px": "70px",
        "350-px": "350px",
        "450-px": "450px",
        "500-px": "500px",
        "600-px": "600px",
      },
      fontSize: {
        "-10-px": "10px",
      },
      padding: {
        "-10-px": "-10px",
        sm: "14px",
      }
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
