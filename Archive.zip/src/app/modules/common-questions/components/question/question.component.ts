import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { AddQuestionComponent } from '../add-question/add-question.component';

@Component({
  selector: 'app-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.scss']
})
export class QuestionComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialog() {
    const dialogRef = this.dialog.open(AddQuestionComponent);
  }

  DeleteFn() {
    Swal.fire({
      title: '<div class="text-primary1 text-lg">Do you want to delete the product?</div>',
      showDenyButton: false,
      showCancelButton: true,
      confirmButtonColor: '#a90520',
      confirmButtonText: `Delete`,
      cancelButtonText: `Cancel`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire('<div class="size-12 weight-700 text-primary">The product has been deleted</div>','',
         'success')
      }
    })
  }

}
