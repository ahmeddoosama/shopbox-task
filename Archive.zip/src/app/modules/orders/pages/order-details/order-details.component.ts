import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { OrderStatusComponent } from '../../components/order-status/order-status.component';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.scss']
})
export class OrderDetailsComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  openDialog() {
    const dialogRef = this.dialog.open(OrderStatusComponent);
  }

  ngOnInit(): void {
  }

}
