import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AmandaServiceDetialsComponent } from './pages/amanda-service-detials/amanda-service-detials.component';
import { AmandaServicesComponent } from './pages/amanda-services/amanda-services.component';

const routes: Routes = [
  {
    path: '',
    component: AmandaServicesComponent
  },
  {
    path: 'service-details',
    component: AmandaServiceDetialsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AmandaServicesRoutingModule { }
