import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccessStoryImgComponent } from './success-story-img.component';

describe('SuccessStoryImgComponent', () => {
  let component: SuccessStoryImgComponent;
  let fixture: ComponentFixture<SuccessStoryImgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SuccessStoryImgComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SuccessStoryImgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
