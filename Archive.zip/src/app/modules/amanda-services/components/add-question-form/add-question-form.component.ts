import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-question-form',
  templateUrl: './add-question-form.component.html',
  styleUrls: ['./add-question-form.component.scss']
})
export class AddQuestionFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
