import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-service-page-form',
  templateUrl: './service-page-form.component.html',
  styleUrls: ['./service-page-form.component.scss']
})
export class ServicePageFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
