import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicePageFormComponent } from './service-page-form.component';

describe('ServicePageFormComponent', () => {
  let component: ServicePageFormComponent;
  let fixture: ComponentFixture<ServicePageFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ServicePageFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ServicePageFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
