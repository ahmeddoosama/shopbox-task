import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AmandaServicesRoutingModule } from './amanda-services-routing.module';
import { AmandaServicesComponent } from './pages/amanda-services/amanda-services.component';
import { SharedModule } from '../@shared/shared.module';
import { ServiceItemComponent } from './components/service-item/service-item.component';
import { AmandaServiceDetialsComponent } from './pages/amanda-service-detials/amanda-service-detials.component';
import { ServiceFormComponent } from './components/service-form/service-form.component';
import { SuccessStoryImgComponent } from './components/success-story-img/success-story-img.component';
import { QuestionsComponent } from './components/questions/questions.component';

import {MatDialogModule} from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { AddQuestionFormComponent } from './components/add-question-form/add-question-form.component';
import { ServicePageFormComponent } from './components/service-page-form/service-page-form.component';
import { NewSessionComponent } from './components/new-session/new-session.component';

@NgModule({
  declarations: [
    AmandaServicesComponent,
    ServiceItemComponent,
    AmandaServiceDetialsComponent,
    ServiceFormComponent,
    SuccessStoryImgComponent,
    QuestionsComponent,
    AddQuestionFormComponent,
    ServicePageFormComponent,
    NewSessionComponent
  ],
  imports: [
    CommonModule,
    AmandaServicesRoutingModule,
    SharedModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
  ]
})
export class AmandaServicesModule { }
