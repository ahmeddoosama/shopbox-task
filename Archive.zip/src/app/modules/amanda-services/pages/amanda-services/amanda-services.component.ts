import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { ServicePageFormComponent } from '../../components/service-page-form/service-page-form.component';

@Component({
  selector: 'app-amanda-services',
  templateUrl: './amanda-services.component.html',
  styleUrls: ['./amanda-services.component.scss']
})
export class AmandaServicesComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialog() {
    const dialogRef = this.dialog.open(ServicePageFormComponent);
  }
}
