import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AmandaServicesComponent } from './amanda-services.component';

describe('AmandaServicesComponent', () => {
  let component: AmandaServicesComponent;
  let fixture: ComponentFixture<AmandaServicesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AmandaServicesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AmandaServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
