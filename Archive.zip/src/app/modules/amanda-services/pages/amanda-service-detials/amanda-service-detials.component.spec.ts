import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AmandaServiceDetialsComponent } from './amanda-service-detials.component';

describe('AmandaServiceDetialsComponent', () => {
  let component: AmandaServiceDetialsComponent;
  let fixture: ComponentFixture<AmandaServiceDetialsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AmandaServiceDetialsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AmandaServiceDetialsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
