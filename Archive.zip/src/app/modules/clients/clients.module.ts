import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientsRoutingModule } from './clients-routing.module';
import { ClientsComponent } from './pages/clients/clients.component';
import { ClientDetailsComponent } from './pages/client-details/client-details.component';
import { SharedModule } from '../@shared/shared.module';
import { TableListCustomerComponent } from './components/table-list-customer/table-list-customer.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ClientConversationComponent } from './components/client-conversation/client-conversation.component';
import { ClientEditComponent } from './components/client-edit/client-edit.component';

import {MatDialogModule} from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';

@NgModule({
  declarations: [
    ClientsComponent,
    ClientDetailsComponent,
    TableListCustomerComponent,
    ClientConversationComponent,
    ClientEditComponent
  ],
  imports: [
    CommonModule,
    ClientsRoutingModule,
    SharedModule,
    InfiniteScrollModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
  ]
})
export class ClientsModule { }
