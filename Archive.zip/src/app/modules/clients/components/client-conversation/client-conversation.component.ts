import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-conversation',
  templateUrl: './client-conversation.component.html',
  styleUrls: ['./client-conversation.component.scss']
})
export class ClientConversationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
