import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-table-list-customer',
  templateUrl: './table-list-customer.component.html',
  styleUrls: ['./table-list-customer.component.scss']
})
export class TableListCustomerComponent implements OnInit {

  array = [];


  constructor() {
    this.array.length = 10;
  }

  ngOnInit(): void {
  }

  onScroll() {
    console.log('scrolled!!');
    this.array.length =  this.array.length + 10;
  }

}
