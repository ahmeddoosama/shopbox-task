import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { ClientEditComponent } from '../../components/client-edit/client-edit.component';

@Component({
  selector: 'app-clients',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.scss']
})
export class ClientsComponent implements OnInit {

  isShown: boolean = false ;

  constructor(public dialog: MatDialog) {
   }

  ngOnInit(): void {
  }

  clientEdit() {
    const dialogRef = this.dialog.open(ClientEditComponent);
  }

  toggleShow() {

    this.isShown = ! this.isShown;

  }
}
