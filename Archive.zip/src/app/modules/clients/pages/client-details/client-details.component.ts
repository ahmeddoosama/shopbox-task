import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';

import Swal from 'sweetalert2';
import { ClientConversationComponent } from '../../components/client-conversation/client-conversation.component';
import { ClientEditComponent } from '../../components/client-edit/client-edit.component';

@Component({
  selector: 'app-client-details',
  templateUrl: './client-details.component.html',
  styleUrls: ['./client-details.component.scss']
})
export class ClientDetailsComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  sendMessage() {
    const dialogRef = this.dialog.open(ClientConversationComponent);
  }

  clientEdit() {
    const dialogRef = this.dialog.open(ClientEditComponent);
  }

  ngOnInit(): void {
  }

  blockClient() {
    Swal.fire({
      title: '<div class="text-primary1 text-lg">Do you want Block this client?</div>',
      showDenyButton: false,
      showCancelButton: true,
      confirmButtonColor: '#a90520',
      confirmButtonText: `Delete`,
      cancelButtonText: `Cancel`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire('<div class="size-12 weight-700 text-primary">Done</div>','',
         'success')
      }
    })
  }

}
