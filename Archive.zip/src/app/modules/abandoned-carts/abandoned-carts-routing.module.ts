import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AbandonedCartsComponent } from './pages/abandoned-carts/abandoned-carts.component';

const routes: Routes = [
  {
    path: '',
    component: AbandonedCartsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AbandonedCartsRoutingModule { }
