import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-abandoned-carts',
  templateUrl: './abandoned-carts.component.html',
  styleUrls: ['./abandoned-carts.component.scss']
})
export class AbandonedCartsComponent implements OnInit {

  isShown: boolean = false ;

  constructor() { }

  ngOnInit(): void {
  }

  toggleShow() {
    this.isShown = ! this.isShown;
  }

}
