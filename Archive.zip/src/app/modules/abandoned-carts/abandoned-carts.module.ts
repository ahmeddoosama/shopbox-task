import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AbandonedCartsRoutingModule } from './abandoned-carts-routing.module';
import { AbandonedTableComponent } from './components/abandoned-table/abandoned-table.component';
import { AbandonedCartsComponent } from './pages/abandoned-carts/abandoned-carts.component';
import { SharedModule } from '../@shared/shared.module';


@NgModule({
  declarations: [
    AbandonedTableComponent,
    AbandonedCartsComponent
  ],
  imports: [
    CommonModule,
    AbandonedCartsRoutingModule,
    SharedModule
  ]
})
export class AbandonedCartsModule { }
