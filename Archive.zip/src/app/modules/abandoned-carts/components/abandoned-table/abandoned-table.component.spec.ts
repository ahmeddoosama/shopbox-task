import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AbandonedTableComponent } from './abandoned-table.component';

describe('AbandonedTableComponent', () => {
  let component: AbandonedTableComponent;
  let fixture: ComponentFixture<AbandonedTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AbandonedTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AbandonedTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
