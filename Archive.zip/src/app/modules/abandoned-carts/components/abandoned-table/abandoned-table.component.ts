import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-abandoned-table',
  templateUrl: './abandoned-table.component.html',
  styleUrls: ['./abandoned-table.component.scss']
})
export class AbandonedTableComponent implements OnInit {

  isTrade: boolean = false
  isNonTrade: boolean = false
  checkAllNonTrades: boolean = false
  checkAllTrades: boolean = false

  nontrade = [
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
    {'name': 'client Name', selected: false},
  ]

  isShown: boolean = false ;

  constructor() {
  }

  ngOnInit(): void {}

  toggleShow() {
    this.isShown = ! this.isShown;
  }

  changeTradesByCategory(event) {
    if (event.target.name == 'trades') {
      this.isTrade = true
    }

    if (event.target.name == 'nontrades') {
      this.isNonTrade = true
    }

    if (this.isNonTrade && this.checkAllNonTrades) {
      event.target.checked = true
    }
  }

  allNonTrades(event) {
    const checked = event.target.checked;
    this.nontrade.forEach(item => item.selected = checked);
  }

}
