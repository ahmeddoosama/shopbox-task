import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LatestAppointmentCardComponent } from './latest-appointment-card.component';

describe('LatestAppointmentCardComponent', () => {
  let component: LatestAppointmentCardComponent;
  let fixture: ComponentFixture<LatestAppointmentCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LatestAppointmentCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LatestAppointmentCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
