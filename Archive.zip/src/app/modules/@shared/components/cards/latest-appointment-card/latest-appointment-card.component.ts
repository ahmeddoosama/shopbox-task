import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-latest-appointment-card',
  templateUrl: './latest-appointment-card.component.html',
  styleUrls: ['./latest-appointment-card.component.scss']
})
export class LatestAppointmentCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
