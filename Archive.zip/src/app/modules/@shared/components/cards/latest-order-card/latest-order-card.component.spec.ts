import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LatestOrderCardComponent } from './latest-order-card.component';

describe('LatestOrderCardComponent', () => {
  let component: LatestOrderCardComponent;
  let fixture: ComponentFixture<LatestOrderCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LatestOrderCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LatestOrderCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
