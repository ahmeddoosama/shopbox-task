import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-latest-order-card',
  templateUrl: './latest-order-card.component.html',
  styleUrls: ['./latest-order-card.component.scss']
})
export class LatestOrderCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
