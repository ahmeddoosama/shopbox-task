import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sessions-table',
  templateUrl: './sessions-table.component.html',
  styleUrls: ['./sessions-table.component.scss']
})
export class SessionsTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
