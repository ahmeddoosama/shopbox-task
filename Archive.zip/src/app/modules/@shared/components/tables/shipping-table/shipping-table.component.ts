import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shipping-table',
  templateUrl: './shipping-table.component.html',
  styleUrls: ['./shipping-table.component.scss']
})
export class ShippingTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
