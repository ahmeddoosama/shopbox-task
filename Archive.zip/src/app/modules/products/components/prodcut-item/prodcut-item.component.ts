import { Component, OnInit, Input } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { AddImgComponent } from '../add-img/add-img.component';
import { EditProductComponent } from '../edit-product/edit-product.component';

@Component({
  selector: 'app-prodcut-item',
  templateUrl: './prodcut-item.component.html',
  styleUrls: ['./prodcut-item.component.scss']
})
export class ProdcutItemComponent implements OnInit {

  @Input()
  get proavilablety(): string {
    return this._proavilablety;
  }
  set proavilablety(proavilablety: string) {
    this._proavilablety = proavilablety === undefined ? "Available" : proavilablety;
  }
  private _proavilablety = "Available";

  @Input()
  get productType(): string {
    return this._productType;
  }
  set productType(productType: string) {
    this._productType = productType === undefined ? "Product Type" : productType;
  }
  private _productType = "Product Type";

  @Input()
  get productName(): string {
    return this._productName;
  }
  set productName(productName: string) {
    this._productName = productName === undefined ? "Product Name" : productName;
  }
  private _productName = "Product Name";

  @Input()
  get proQuantity(): string {
    return this._proQuantity;
  }
  set proQuantity(proQuantity: string) {
    this._proQuantity = proQuantity === undefined ? "0" : proQuantity;
  }
  private _proQuantity = "0";

  @Input()
  get proSalePrice(): string {
    return this._proSalePrice;
  }
  set proSalePrice(proSalePrice: string) {
    this._proSalePrice = proSalePrice === undefined ? "45,000" : proSalePrice;
  }
  private _proSalePrice = "45,000";

  @Input()
  get productPrice(): string {
    return this._productPrice;
  }
  set productPrice(productPrice: string) {
    this._productPrice = productPrice === undefined ? "80,000" : productPrice;
  }
  private _productPrice = "80,000";

  constructor(public dialog: MatDialog) {}

  openImg() {
    const dialogRef = this.dialog.open(AddImgComponent);
  }

  openDialog() {
    const dialogRef = this.dialog.open(EditProductComponent);
  }

  DeleteFn() {
    Swal.fire({
      title: '<div class="text-primary1 text-lg">Do you want to delete the product?</div>',
      showDenyButton: false,
      showCancelButton: true,
      confirmButtonColor: '#a90520',
      confirmButtonText: `Delete`,
      cancelButtonText: `Cancel`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire('<div class="size-12 weight-700 text-primary">The product has been deleted</div>','',
         'success')
      }
    })
  }

  ngOnInit(): void {
  }

}
