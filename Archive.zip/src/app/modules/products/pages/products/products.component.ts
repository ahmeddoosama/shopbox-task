import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { EditProductComponent } from '../../components/edit-product/edit-product.component';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.scss']
})
export class ProductsComponent implements OnInit {

  array = [];

  constructor(public dialog: MatDialog) {
    this.array.length = 10;
  }

  openDialog() {
    const dialogRef = this.dialog.open(EditProductComponent);
  }

  ngOnInit(): void {
  }

  onScroll() {
    console.log('scrolled!!');
    this.array.length =  this.array.length + 10;
  }
}
