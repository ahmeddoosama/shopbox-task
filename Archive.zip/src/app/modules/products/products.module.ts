import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProductsRoutingModule } from './products-routing.module';
import { ProductsComponent } from './pages/products/products.component';
import { ProductDetailsComponent } from './pages/product-details/product-details.component';
import { ProdcutItemComponent } from './components/prodcut-item/prodcut-item.component';
import { EditProductComponent } from './components/edit-product/edit-product.component';
import { AddImgComponent } from './components/add-img/add-img.component';
import { SharedModule } from '../@shared/shared.module';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

import {MatDialogModule} from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';


@NgModule({
  declarations: [
    ProductsComponent,
    ProductDetailsComponent,
    ProdcutItemComponent,
    EditProductComponent,
    AddImgComponent
  ],
  imports: [
    CommonModule,
    ProductsRoutingModule,
    SharedModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
    InfiniteScrollModule
  ]
})
export class ProductsModule { }
