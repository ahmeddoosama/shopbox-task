import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-latest-orders',
  templateUrl: './latest-orders.component.html',
  styleUrls: ['./latest-orders.component.scss']
})
export class LatestOrdersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
