import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrductsSoldComponent } from './prducts-sold.component';

describe('PrductsSoldComponent', () => {
  let component: PrductsSoldComponent;
  let fixture: ComponentFixture<PrductsSoldComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrductsSoldComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrductsSoldComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
