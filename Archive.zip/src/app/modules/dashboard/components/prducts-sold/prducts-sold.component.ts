import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prducts-sold',
  templateUrl: './prducts-sold.component.html',
  styleUrls: ['./prducts-sold.component.scss']
})
export class PrductsSoldComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
