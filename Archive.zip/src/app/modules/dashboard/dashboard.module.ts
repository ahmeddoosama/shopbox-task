import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { DashboardStatsComponent } from './components/dashboard-stats/dashboard-stats.component';
import { LatestOrdersComponent } from './components/latest-orders/latest-orders.component';
import { NotificationsListComponent } from './components/notifications-list/notifications-list.component';
import { PrductsSoldComponent } from './components/prducts-sold/prducts-sold.component';
import { SharedModule } from '../@shared/shared.module';
import { CardLineChartComponent } from './components/card-line-chart/card-line-chart.component';
import { SessionsComponent } from './components/sessions/sessions.component';
import { AppointmentsComponent } from './components/appointments/appointments.component';


@NgModule({
  declarations: [
    DashboardComponent,
    DashboardStatsComponent,
    LatestOrdersComponent,
    NotificationsListComponent,
    PrductsSoldComponent,
    CardLineChartComponent,
    SessionsComponent,
    AppointmentsComponent
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    SharedModule
  ]
})
export class DashboardModule { }
