import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slogans',
  templateUrl: './slogans.component.html',
  styleUrls: ['./slogans.component.scss']
})
export class SlogansComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
