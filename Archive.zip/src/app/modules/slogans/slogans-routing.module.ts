import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SlogansComponent } from './pages/slogans/slogans.component';

const routes: Routes = [
  {
    path: '',
    component: SlogansComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SlogansRoutingModule { }
