import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SlogansRoutingModule } from './slogans-routing.module';
import { SlogansComponent } from './pages/slogans/slogans.component';
import { SharedModule } from '../@shared/shared.module';


@NgModule({
  declarations: [
    SlogansComponent
  ],
  imports: [
    CommonModule,
    SlogansRoutingModule,
    SharedModule
  ]
})
export class SlogansModule { }
