import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss']
})
export class SideNavComponent implements OnInit {
  collapseShow = "hidden";

  constructor() { }

  ngOnInit(): void {
  }

  toggleCollapseShow(classes) {
    this.collapseShow = classes;
  }

}
