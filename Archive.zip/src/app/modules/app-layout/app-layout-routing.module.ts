import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppLayoutComponent } from './app-layout.component';

const routes: Routes = [
  {
    path: '',
    component: AppLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () => import('../dashboard/dashboard.module').then(m => m.DashboardModule)
      },
      {
        path: 'products',
        loadChildren: () => import('../products/products.module').then(m => m.ProductsModule)
      },
      {
        path: 'orders',
        loadChildren: () => import('../orders/orders.module').then(m => m.OrdersModule)
      },
      {
        path: 'clients',
        loadChildren: () => import('../clients/clients.module').then(m => m.ClientsModule)
      },
      {
        path: 'doctors',
        loadChildren: () => import('../doctors/doctors.module').then(m => m.DoctorsModule)
      },
      {
        path: 'reports',
        loadChildren: () => import('../reports/reports.module').then(m => m.ReportsModule)
      },
      {
        path: 'faq',
        loadChildren: () => import('../faq/faq.module').then(m => m.FaqModule)
      },
      {
        path: 'introductory-pages',
        loadChildren: () => import('../introductory-pages/introductory-pages.module').then(m => m.IntroductoryPagesModule)
      },
      {
        path: 'coupons',
        loadChildren: () => import('../coupons/coupons.module').then(m => m.CouponsModule)
      },
      {
        path: 'abandoned-carts',
        loadChildren: () => import('../abandoned-carts/abandoned-carts.module').then(m => m.AbandonedCartsModule)
      },
      {
        path: 'general-setting',
        loadChildren: () => import('../general-setting/general-setting.module').then(m => m.GeneralSettingModule)
      },
      {
        path: 'account-setting',
        loadChildren: () => import('../account-setting/account-setting.module').then(m => m.AccountSettingModule)
      },
      {
        path: 'amanda-services',
        loadChildren: () => import('../amanda-services/amanda-services.module').then(m => m.AmandaServicesModule)
      },
      {
        path: 'sessions',
        loadChildren: () => import('../sessions/sessions.module').then(m => m.SessionsModule)
      },
      {
        path: 'health-edu',
        loadChildren: () => import('../health-educations/health-educations.module').then(m => m.HealthEducationsModule)
      },
      {
        path: 'blogs',
        loadChildren: () => import('../blogs/blogs.module').then(m => m.BlogsModule)
      },
      {
        path: 'appointment',
        loadChildren: () => import('../appointment/appointment.module').then(m => m.AppointmentModule)
      },
      {
        path: 'common-question',
        loadChildren: () => import('../common-questions/common-questions.module').then(m => m.CommonQuestionsModule)
      },
      {
        path: 'jobs',
        loadChildren: () => import('../jobs/jobs.module').then(m => m.JobsModule)
      },
      {
        path: 'slogans',
        loadChildren: () => import('../slogans/slogans.module').then(m => m.SlogansModule)
      },
      {
        path: 'about-us',
        loadChildren: () => import('../about-us/about-us.module').then(m => m.AboutUsModule)
      },
      {
        path: 'join-us',
        loadChildren: () => import('../join-us/join-us.module').then(m => m.JoinUsModule)
      },
      {
        path: 'Customer-opinions',
        loadChildren: () => import('../customer-opinions/customer-opinions.module').then(m => m.CustomerOpinionsModule)
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppLayoutRoutingModule { }
