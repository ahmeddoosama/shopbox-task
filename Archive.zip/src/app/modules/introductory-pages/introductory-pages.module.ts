import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { IntroductoryPagesRoutingModule } from './introductory-pages-routing.module';
import { IntroductoryPagesComponent } from './pages/introductory-pages/introductory-pages.component';
import { SharedModule } from '../@shared/shared.module';
import { PrivacyPolicyComponent } from './components/privacy-policy/privacy-policy.component';

import { MatDialogModule } from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MembershipsComponent } from './components/memberships/memberships.component';
import { AboutUsComponent } from './components/about-us/about-us.component';

@NgModule({
  declarations: [
    IntroductoryPagesComponent,
    PrivacyPolicyComponent,
    MembershipsComponent,
    AboutUsComponent
  ],
  imports: [
    CommonModule,
    IntroductoryPagesRoutingModule,
    SharedModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
  ]
})
export class IntroductoryPagesModule { }
