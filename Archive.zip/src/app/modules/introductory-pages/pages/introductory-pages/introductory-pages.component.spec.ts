import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IntroductoryPagesComponent } from './introductory-pages.component';

describe('IntroductoryPagesComponent', () => {
  let component: IntroductoryPagesComponent;
  let fixture: ComponentFixture<IntroductoryPagesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IntroductoryPagesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IntroductoryPagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
