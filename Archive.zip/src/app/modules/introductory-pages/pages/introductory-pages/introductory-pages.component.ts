import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { PrivacyPolicyComponent } from '../../components/privacy-policy/privacy-policy.component';
import { MembershipsComponent } from '../../components/memberships/memberships.component';
import { AboutUsComponent } from '../../components/about-us/about-us.component';

@Component({
  selector: 'app-introductory-pages',
  templateUrl: './introductory-pages.component.html',
  styleUrls: ['./introductory-pages.component.scss']
})
export class IntroductoryPagesComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  privacyPolicy() {
    const dialogRef = this.dialog.open(PrivacyPolicyComponent);
  }

  memberships() {
    const dialogRef = this.dialog.open(MembershipsComponent);
  }

  aboutUs() {
    const dialogRef = this.dialog.open(AboutUsComponent);
  }

}
