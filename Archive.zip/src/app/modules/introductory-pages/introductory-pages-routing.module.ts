import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IntroductoryPagesComponent } from './pages/introductory-pages/introductory-pages.component';

const routes: Routes = [
  {
    path: '',
    component: IntroductoryPagesComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class IntroductoryPagesRoutingModule { }
