import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-memberships',
  templateUrl: './memberships.component.html',
  styleUrls: ['./memberships.component.scss']
})
export class MembershipsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
