import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-edit',
  templateUrl: './doctor-edit.component.html',
  styleUrls: ['./doctor-edit.component.scss']
})
export class DoctorEditComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
