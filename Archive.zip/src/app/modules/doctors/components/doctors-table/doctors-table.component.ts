import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctors-table',
  templateUrl: './doctors-table.component.html',
  styleUrls: ['./doctors-table.component.scss']
})
export class DoctorsTableComponent implements OnInit {

  array = [];

  constructor() { }

  ngOnInit(): void {
    this.array.length = 10;
  }

  onScroll() {
    console.log('scrolled!!');
    this.array.length =  this.array.length + 10;
  }
}
