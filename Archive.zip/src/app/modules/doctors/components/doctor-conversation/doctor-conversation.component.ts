import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctor-conversation',
  templateUrl: './doctor-conversation.component.html',
  styleUrls: ['./doctor-conversation.component.scss']
})
export class DoctorConversationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
