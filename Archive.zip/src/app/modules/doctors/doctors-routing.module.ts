import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DoctorDetailsComponent } from './pages/doctor-details/doctor-details.component';
import { DoctorsComponent } from './pages/doctors/doctors.component';

const routes: Routes = [
  {
    path: '',
    component: DoctorsComponent,
  },
  {
    path: 'doctor-details',
    component: DoctorDetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DoctorsRoutingModule { }
