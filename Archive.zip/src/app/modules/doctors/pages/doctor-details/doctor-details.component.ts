import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { DoctorConversationComponent } from '../../components/doctor-conversation/doctor-conversation.component';
import { DoctorEditComponent } from '../../components/doctor-edit/doctor-edit.component';

@Component({
  selector: 'app-doctor-details',
  templateUrl: './doctor-details.component.html',
  styleUrls: ['./doctor-details.component.scss']
})
export class DoctorDetailsComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  sendMessage() {
    const dialogRef = this.dialog.open(DoctorConversationComponent);
  }

  clientEdit() {
    const dialogRef = this.dialog.open(DoctorEditComponent);
  }

  ngOnInit(): void {
  }

  blockClient() {
    Swal.fire({
      title: '<div class="text-primary1 text-lg">Do you want Block this client?</div>',
      showDenyButton: false,
      showCancelButton: true,
      confirmButtonColor: '#a90520',
      confirmButtonText: `Delete`,
      cancelButtonText: `Cancel`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire('<div class="size-12 weight-700 text-primary">Done</div>','',
         'success')
      }
    })
  }

}
