import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { DoctorEditComponent } from '../../components/doctor-edit/doctor-edit.component';

@Component({
  selector: 'app-doctors',
  templateUrl: './doctors.component.html',
  styleUrls: ['./doctors.component.scss']
})
export class DoctorsComponent implements OnInit {

  isShown: boolean = false ;

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }
  doctorEdit() {
    const dialogRef = this.dialog.open(DoctorEditComponent);
  }

  toggleShow() {
    this.isShown = ! this.isShown;
  }

}
