import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DoctorsRoutingModule } from './doctors-routing.module';
import { DoctorsComponent } from './pages/doctors/doctors.component';
import { DoctorDetailsComponent } from './pages/doctor-details/doctor-details.component';
import { DoctorsTableComponent } from './components/doctors-table/doctors-table.component';
import { SharedModule } from '../@shared/shared.module';

import {MatDialogModule} from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { DoctorEditComponent } from './components/doctor-edit/doctor-edit.component';
import { DoctorConversationComponent } from './components/doctor-conversation/doctor-conversation.component';


@NgModule({
  declarations: [
    DoctorsComponent,
    DoctorDetailsComponent,
    DoctorsTableComponent,
    DoctorEditComponent,
    DoctorConversationComponent
  ],
  imports: [
    CommonModule,
    DoctorsRoutingModule,
    SharedModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
    InfiniteScrollModule,
  ]
})
export class DoctorsModule { }
