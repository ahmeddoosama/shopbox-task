import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-table-sales',
  templateUrl: './table-sales.component.html',
  styleUrls: ['./table-sales.component.scss']
})
export class TableSalesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
