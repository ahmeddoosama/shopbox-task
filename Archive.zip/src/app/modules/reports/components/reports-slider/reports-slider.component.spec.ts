import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsSliderComponent } from './reports-slider.component';

describe('ReportsSliderComponent', () => {
  let component: ReportsSliderComponent;
  let fixture: ComponentFixture<ReportsSliderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportsSliderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportsSliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
