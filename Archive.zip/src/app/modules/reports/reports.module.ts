import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsComponent } from './pages/reports/reports.component';
import { DatepickerComponent } from './components/datepicker/datepicker.component';
import { ReportsSliderComponent } from './components/reports-slider/reports-slider.component';
import { TableSalesComponent } from './components/table-sales/table-sales.component';
import { SharedModule } from '../@shared/shared.module';

import { CarouselModule } from 'ngx-owl-carousel-o';


@NgModule({
  declarations: [
    ReportsComponent,
    DatepickerComponent,
    ReportsSliderComponent,
    TableSalesComponent
  ],
  imports: [
    CommonModule,
    ReportsRoutingModule,
    SharedModule,
    CarouselModule
  ]
})
export class ReportsModule { }
