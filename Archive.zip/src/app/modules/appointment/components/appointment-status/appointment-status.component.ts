import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-status',
  templateUrl: './appointment-status.component.html',
  styleUrls: ['./appointment-status.component.scss']
})
export class AppointmentStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
