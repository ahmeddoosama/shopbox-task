import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { HealthEduPageFormComponent } from '../../components/health-edu-page-form/health-edu-page-form.component';

@Component({
  selector: 'app-health-educations',
  templateUrl: './health-educations.component.html',
  styleUrls: ['./health-educations.component.scss']
})
export class HealthEducationsComponent implements OnInit {

  array = [];

  constructor(public dialog: MatDialog) {
    this.array.length = 10;
  }

  ngOnInit(): void {
  }

  openDialog() {
    const dialogRef = this.dialog.open(HealthEduPageFormComponent);
  }

  onScroll() {
    console.log('scrolled!!');
    this.array.length =  this.array.length + 10;
  }

}
