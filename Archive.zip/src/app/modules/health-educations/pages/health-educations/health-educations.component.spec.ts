import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HealthEducationsComponent } from './health-educations.component';

describe('HealthEducationsComponent', () => {
  let component: HealthEducationsComponent;
  let fixture: ComponentFixture<HealthEducationsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HealthEducationsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HealthEducationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
