import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HealthEducationDetailsComponent } from './health-education-details.component';

describe('HealthEducationDetailsComponent', () => {
  let component: HealthEducationDetailsComponent;
  let fixture: ComponentFixture<HealthEducationDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HealthEducationDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HealthEducationDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
