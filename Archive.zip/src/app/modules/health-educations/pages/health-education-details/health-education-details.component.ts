import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-health-education-details',
  templateUrl: './health-education-details.component.html',
  styleUrls: ['./health-education-details.component.scss']
})
export class HealthEducationDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  uploadedImage: any = [];
  uploadedImageFiles = [];

  preview(files) {

    if (files.length === 0) {
    return;
    }
    for (let i = 0; i < files.length; i++) {
    const mimeType = files[i].type;
    if (mimeType.match(/image\/*/) == null) {
    return;
    }
    const reader = new FileReader();
    reader.readAsDataURL(files[i]);

    reader.onload = (_event) => {
    this.uploadedImage.push(reader.result);
    };
    this.uploadedImageFiles.push(files[i]);
    }

    }
    onFileChange(event) {
    if (event.target.files && event.target.files.length) {
    this.preview(event.target.files);
    const [file] = event.target.files;


    }
    }

  DeleteFn() {
    Swal.fire({
      title: '<div class="text-primary1 text-lg">Do you want to delete the product?</div>',
      showDenyButton: false,
      showCancelButton: true,
      confirmButtonColor: '#a90520',
      confirmButtonText: `Delete`,
      cancelButtonText: `Cancel`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire('<div class="size-12 weight-700 text-primary">The product has been deleted</div>','',
         'success')
      }
    })
  }

}
