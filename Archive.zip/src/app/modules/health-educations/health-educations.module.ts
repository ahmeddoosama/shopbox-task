import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HealthEducationsRoutingModule } from './health-educations-routing.module';
import { HealthEducationsComponent } from './pages/health-educations/health-educations.component';
import { HealthEducationDetailsComponent } from './pages/health-education-details/health-education-details.component';
import { HealthEducationItemComponent } from './components/health-education-item/health-education-item.component';

import {MatDialogModule} from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { SharedModule } from '../@shared/shared.module';
import { HealthEduPageFormComponent } from './components/health-edu-page-form/health-edu-page-form.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { HealthEduFormComponent } from './components/health-edu-form/health-edu-form.component';

@NgModule({
  declarations: [
    HealthEducationsComponent,
    HealthEducationDetailsComponent,
    HealthEducationItemComponent,
    HealthEduPageFormComponent,
    HealthEduFormComponent
  ],
  imports: [
    CommonModule,
    HealthEducationsRoutingModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
    SharedModule,
    InfiniteScrollModule
  ]
})
export class HealthEducationsModule { }
