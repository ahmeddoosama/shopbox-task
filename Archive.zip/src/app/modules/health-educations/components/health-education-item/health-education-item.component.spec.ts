import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HealthEducationItemComponent } from './health-education-item.component';

describe('HealthEducationItemComponent', () => {
  let component: HealthEducationItemComponent;
  let fixture: ComponentFixture<HealthEducationItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HealthEducationItemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HealthEducationItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
