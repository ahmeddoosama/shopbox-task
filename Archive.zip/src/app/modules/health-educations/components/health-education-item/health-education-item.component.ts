import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-health-education-item',
  templateUrl: './health-education-item.component.html',
  styleUrls: ['./health-education-item.component.scss']
})
export class HealthEducationItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
