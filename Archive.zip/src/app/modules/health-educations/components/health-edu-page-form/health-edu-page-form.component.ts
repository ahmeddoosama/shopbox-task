import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-health-edu-page-form',
  templateUrl: './health-edu-page-form.component.html',
  styleUrls: ['./health-edu-page-form.component.scss']
})
export class HealthEduPageFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
