import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HealthEduPageFormComponent } from './health-edu-page-form.component';

describe('HealthEduPageFormComponent', () => {
  let component: HealthEduPageFormComponent;
  let fixture: ComponentFixture<HealthEduPageFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HealthEduPageFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HealthEduPageFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
