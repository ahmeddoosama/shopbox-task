import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-health-edu-form',
  templateUrl: './health-edu-form.component.html',
  styleUrls: ['./health-edu-form.component.scss']
})
export class HealthEduFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
