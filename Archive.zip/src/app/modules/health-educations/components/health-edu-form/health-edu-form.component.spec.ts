import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HealthEduFormComponent } from './health-edu-form.component';

describe('HealthEduFormComponent', () => {
  let component: HealthEduFormComponent;
  let fixture: ComponentFixture<HealthEduFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HealthEduFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HealthEduFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
