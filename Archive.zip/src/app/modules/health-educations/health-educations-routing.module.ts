import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HealthEducationDetailsComponent } from './pages/health-education-details/health-education-details.component';
import { HealthEducationsComponent } from './pages/health-educations/health-educations.component';

const routes: Routes = [
  {
    path: '',
    component: HealthEducationsComponent
  },
  {
    path: 'healthEdu-details',
    component: HealthEducationDetailsComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HealthEducationsRoutingModule { }
