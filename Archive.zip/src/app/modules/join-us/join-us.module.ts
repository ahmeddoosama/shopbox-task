import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { JoinUsRoutingModule } from './join-us-routing.module';
import { JoinUsComponent } from './pages/join-us/join-us.component';
import { SharedModule } from '../@shared/shared.module';
import { OurMomentImagesComponent } from './components/our-moment-images/our-moment-images.component';


@NgModule({
  declarations: [
    JoinUsComponent,
    OurMomentImagesComponent
  ],
  imports: [
    CommonModule,
    JoinUsRoutingModule,
    SharedModule
  ]
})
export class JoinUsModule { }
