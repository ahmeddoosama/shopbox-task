import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OurMomentImagesComponent } from './our-moment-images.component';

describe('OurMomentImagesComponent', () => {
  let component: OurMomentImagesComponent;
  let fixture: ComponentFixture<OurMomentImagesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OurMomentImagesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OurMomentImagesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
