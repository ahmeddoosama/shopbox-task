import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-moment-images',
  templateUrl: './our-moment-images.component.html',
  styleUrls: ['./our-moment-images.component.scss']
})
export class OurMomentImagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
