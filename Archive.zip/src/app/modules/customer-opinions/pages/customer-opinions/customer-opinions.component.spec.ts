import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerOpinionsComponent } from './customer-opinions.component';

describe('CustomerOpinionsComponent', () => {
  let component: CustomerOpinionsComponent;
  let fixture: ComponentFixture<CustomerOpinionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerOpinionsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerOpinionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
