import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-opinions',
  templateUrl: './customer-opinions.component.html',
  styleUrls: ['./customer-opinions.component.scss']
})
export class CustomerOpinionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
