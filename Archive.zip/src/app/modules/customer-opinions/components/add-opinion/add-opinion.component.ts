import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-opinion',
  templateUrl: './add-opinion.component.html',
  styleUrls: ['./add-opinion.component.scss']
})
export class AddOpinionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
