import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomerOpinionsRoutingModule } from './customer-opinions-routing.module';
import { CustomerOpinionsComponent } from './pages/customer-opinions/customer-opinions.component';
import { ReviewItemComponent } from './components/review-item/review-item.component';
import { SharedModule } from '../@shared/shared.module';

import {MatDialogModule} from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { AddOpinionComponent } from './components/add-opinion/add-opinion.component';

@NgModule({
  declarations: [
    CustomerOpinionsComponent,
    ReviewItemComponent,
    AddOpinionComponent
  ],
  imports: [
    CommonModule,
    CustomerOpinionsRoutingModule,
    SharedModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
  ]
})
export class CustomerOpinionsModule { }
