import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { CouponsTabsComponent } from '../../components/coupons-tabs/coupons-tabs.component';

@Component({
  selector: 'app-coupons',
  templateUrl: './coupons.component.html',
  styleUrls: ['./coupons.component.scss']
})
export class CouponsComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  couponTabs() {
    const dialogRef = this.dialog.open(CouponsTabsComponent);
  }

}
