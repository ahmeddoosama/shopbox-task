import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coupons-table',
  templateUrl: './coupons-table.component.html',
  styleUrls: ['./coupons-table.component.scss']
})
export class CouponsTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
