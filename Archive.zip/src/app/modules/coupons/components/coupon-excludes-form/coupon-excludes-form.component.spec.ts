import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CouponExcludesFormComponent } from './coupon-excludes-form.component';

describe('CouponExcludesFormComponent', () => {
  let component: CouponExcludesFormComponent;
  let fixture: ComponentFixture<CouponExcludesFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CouponExcludesFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponExcludesFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
