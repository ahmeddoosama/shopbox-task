import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coupon-excludes-form',
  templateUrl: './coupon-excludes-form.component.html',
  styleUrls: ['./coupon-excludes-form.component.scss']
})
export class CouponExcludesFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
