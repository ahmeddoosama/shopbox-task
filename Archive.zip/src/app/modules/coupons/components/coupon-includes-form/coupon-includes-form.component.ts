import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coupon-includes-form',
  templateUrl: './coupon-includes-form.component.html',
  styleUrls: ['./coupon-includes-form.component.scss']
})
export class CouponIncludesFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
