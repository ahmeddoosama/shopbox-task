import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CouponIncludesFormComponent } from './coupon-includes-form.component';

describe('CouponIncludesFormComponent', () => {
  let component: CouponIncludesFormComponent;
  let fixture: ComponentFixture<CouponIncludesFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CouponIncludesFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponIncludesFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
