import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coupons-tabs',
  templateUrl: './coupons-tabs.component.html',
  styleUrls: ['./coupons-tabs.component.scss']
})
export class CouponsTabsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
