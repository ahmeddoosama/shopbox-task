import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CouponsTabsComponent } from './coupons-tabs.component';

describe('CouponsTabsComponent', () => {
  let component: CouponsTabsComponent;
  let fixture: ComponentFixture<CouponsTabsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CouponsTabsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponsTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
