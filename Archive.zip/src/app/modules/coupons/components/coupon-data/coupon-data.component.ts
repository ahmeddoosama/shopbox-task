import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-coupon-data',
  templateUrl: './coupon-data.component.html',
  styleUrls: ['./coupon-data.component.scss']
})
export class CouponDataComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
