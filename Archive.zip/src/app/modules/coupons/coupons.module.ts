import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CouponsRoutingModule } from './coupons-routing.module';
import { CouponsComponent } from './pages/coupons/coupons.component';
import { CouponDataComponent } from './components/coupon-data/coupon-data.component';
import { CouponExcludesFormComponent } from './components/coupon-excludes-form/coupon-excludes-form.component';
import { CouponIncludesFormComponent } from './components/coupon-includes-form/coupon-includes-form.component';
import { CouponsTableComponent } from './components/coupons-table/coupons-table.component';
import { CouponsTabsComponent } from './components/coupons-tabs/coupons-tabs.component';
import { SharedModule } from '../@shared/shared.module';

import { MatDialogModule } from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';


@NgModule({
  declarations: [
    CouponsComponent,
    CouponDataComponent,
    CouponExcludesFormComponent,
    CouponIncludesFormComponent,
    CouponsTableComponent,
    CouponsTabsComponent
  ],
  imports: [
    CommonModule,
    CouponsRoutingModule,
    SharedModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
  ]
})
export class CouponsModule { }
