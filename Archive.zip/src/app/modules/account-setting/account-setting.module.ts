import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountSettingRoutingModule } from './account-setting-routing.module';
import { AccountSettingComponent } from './pages/account-setting/account-setting.component';
import { SharedModule } from '../@shared/shared.module';


@NgModule({
  declarations: [
    AccountSettingComponent
  ],
  imports: [
    CommonModule,
    AccountSettingRoutingModule,
    SharedModule
  ]
})
export class AccountSettingModule { }
