import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FaqRoutingModule } from './faq-routing.module';
import { FaqComponent } from './pages/faq/faq.component';
import { FaqItemComponent } from './components/faq-item/faq-item.component';
import { SharedModule } from '../@shared/shared.module';


@NgModule({
  declarations: [
    FaqComponent,
    FaqItemComponent
  ],
  imports: [
    CommonModule,
    FaqRoutingModule,
    SharedModule
  ]
})
export class FaqModule { }
