import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GeneralSettingRoutingModule } from './general-setting-routing.module';
import { GeneralSettingComponent } from './pages/general-setting/general-setting.component';
import { CardSettingComponent } from './components/card-setting/card-setting.component';
import { SharedModule } from '../@shared/shared.module';
import { BasicFormComponent } from './pages/basic-form/basic-form.component';
import { SocialSettingFormComponent } from './pages/social-setting-form/social-setting-form.component';
import { SocailCardComponent } from './components/socail-card/socail-card.component';
import { PlaceOfBirthComponent } from './pages/place-of-birth/place-of-birth.component';
import { PlaceCardComponent } from './components/place-card/place-card.component';
import { EducationFormComponent } from './pages/education-form/education-form.component';
import { EducationCardComponent } from './components/education-card/education-card.component';
import { NationalityComponent } from './pages/nationality/nationality.component';
import { NationalityCardComponent } from './components/nationality-card/nationality-card.component';
import { ZonesTableComponent } from './components/zones-table/zones-table.component';


import { MatDialogModule } from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { ZonesFormComponent } from './components/zones-form/zones-form.component';
import { CititeTableComponent } from './components/citite-table/citite-table.component';
import { CitityFormComponent } from './components/citity-form/citity-form.component';
import { EducationComponent } from './pages/education/education.component';
import { QualificationTableComponent } from './components/qualification-table/qualification-table.component';
import { QualificationFormComponent } from './components/qualification-form/qualification-form.component';
import { SpecializationTableComponent } from './components/specialization-table/specialization-table.component';
import { SpecializationFormComponent } from './components/specialization-form/specialization-form.component';
import { NationalityTableComponent } from './components/nationality-table/nationality-table.component';
import { NationalityFormComponent } from './components/nationality-form/nationality-form.component';
import { LanguagesComponent } from './pages/languages/languages.component';
import { LanguagesTableComponent } from './components/languages-table/languages-table.component';
import { LanguagesFormComponent } from './components/languages-form/languages-form.component';
import { LanguageCardComponent } from './components/language-card/language-card.component';
import { ZonesComponent } from './pages/zones/zones.component';

@NgModule({
  declarations: [
    GeneralSettingComponent,
    CardSettingComponent,
    BasicFormComponent,
    SocialSettingFormComponent,
    SocailCardComponent,
    PlaceOfBirthComponent,
    PlaceCardComponent,
    EducationFormComponent,
    EducationCardComponent,
    NationalityComponent,
    NationalityCardComponent,
    ZonesTableComponent,
    ZonesFormComponent,
    CititeTableComponent,
    CitityFormComponent,
    EducationComponent,
    QualificationTableComponent,
    QualificationFormComponent,
    SpecializationTableComponent,
    SpecializationFormComponent,
    NationalityTableComponent,
    NationalityFormComponent,
    LanguagesComponent,
    LanguagesTableComponent,
    LanguagesFormComponent,
    LanguageCardComponent,
    ZonesComponent
  ],
  imports: [
    CommonModule,
    GeneralSettingRoutingModule,
    SharedModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
  ]
})
export class GeneralSettingModule { }
