import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import {MatDialog} from '@angular/material/dialog';
import { QualificationFormComponent } from '../../components/qualification-form/qualification-form.component';
import { SpecializationFormComponent } from '../../components/specialization-form/specialization-form.component';

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.scss']
})
export class EducationComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  qualification() {
    const dialogRef = this.dialog.open(QualificationFormComponent);
  }

  specialization() {
    const dialogRef = this.dialog.open(SpecializationFormComponent);
  }

}
