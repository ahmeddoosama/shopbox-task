import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SocialSettingFormComponent } from './social-setting-form.component';

describe('SocialSettingFormComponent', () => {
  let component: SocialSettingFormComponent;
  let fixture: ComponentFixture<SocialSettingFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SocialSettingFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SocialSettingFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
