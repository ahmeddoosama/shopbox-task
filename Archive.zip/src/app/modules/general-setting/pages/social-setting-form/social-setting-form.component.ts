import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social-setting-form',
  templateUrl: './social-setting-form.component.html',
  styleUrls: ['./social-setting-form.component.scss']
})
export class SocialSettingFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
