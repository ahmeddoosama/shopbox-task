import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { NationalityFormComponent } from '../../components/nationality-form/nationality-form.component';

@Component({
  selector: 'app-nationality',
  templateUrl: './nationality.component.html',
  styleUrls: ['./nationality.component.scss']
})
export class NationalityComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  nationality() {
    const dialogRef = this.dialog.open(NationalityFormComponent);
  }

}
