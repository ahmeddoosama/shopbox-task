import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import {MatDialog} from '@angular/material/dialog';
import { ZonesFormComponent } from '../../components/zones-form/zones-form.component';
import { CitityFormComponent } from '../../components/citity-form/citity-form.component';

@Component({
  selector: 'app-place-of-birth',
  templateUrl: './place-of-birth.component.html',
  styleUrls: ['./place-of-birth.component.scss']
})
export class PlaceOfBirthComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openZones() {
    const dialogRef = this.dialog.open(ZonesFormComponent);
  }

  openCities() {
    const dialogRef = this.dialog.open(CitityFormComponent);
  }

}
