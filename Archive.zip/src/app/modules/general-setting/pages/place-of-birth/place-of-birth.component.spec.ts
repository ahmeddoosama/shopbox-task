import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceOfBirthComponent } from './place-of-birth.component';

describe('PlaceOfBirthComponent', () => {
  let component: PlaceOfBirthComponent;
  let fixture: ComponentFixture<PlaceOfBirthComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlaceOfBirthComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaceOfBirthComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
