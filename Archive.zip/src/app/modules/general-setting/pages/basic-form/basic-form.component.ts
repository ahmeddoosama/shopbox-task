import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-form',
  templateUrl: './basic-form.component.html',
  styleUrls: ['./basic-form.component.scss']
})
export class BasicFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  uploadedImage: any = [];
  uploadedImageFiles = [];

  preview(files) {

    if (files.length === 0) {
    return;
    }
    for (let i = 0; i < files.length; i++) {
    const mimeType = files[i].type;
    if (mimeType.match(/image\/*/) == null) {
    return;
    }
    const reader = new FileReader();
    reader.readAsDataURL(files[i]);

    reader.onload = (_event) => {
    this.uploadedImage.push(reader.result);
    };
    this.uploadedImageFiles.push(files[i]);
    }

    }
    onFileChange(event) {
    if (event.target.files && event.target.files.length) {
    this.preview(event.target.files);
    const [file] = event.target.files;


    }
    }

}
