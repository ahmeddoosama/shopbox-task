import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-education-form',
  templateUrl: './education-form.component.html',
  styleUrls: ['./education-form.component.scss']
})
export class EducationFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
