import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CititeTableComponent } from './citite-table.component';

describe('CititeTableComponent', () => {
  let component: CititeTableComponent;
  let fixture: ComponentFixture<CititeTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CititeTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CititeTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
