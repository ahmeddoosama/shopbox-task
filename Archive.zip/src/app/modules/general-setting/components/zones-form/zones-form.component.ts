import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-zones-form',
  templateUrl: './zones-form.component.html',
  styleUrls: ['./zones-form.component.scss']
})
export class ZonesFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
