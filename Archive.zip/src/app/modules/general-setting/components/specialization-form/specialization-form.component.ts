import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-specialization-form',
  templateUrl: './specialization-form.component.html',
  styleUrls: ['./specialization-form.component.scss']
})
export class SpecializationFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
