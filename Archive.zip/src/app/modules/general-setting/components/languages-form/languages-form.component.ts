import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-languages-form',
  templateUrl: './languages-form.component.html',
  styleUrls: ['./languages-form.component.scss']
})
export class LanguagesFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
