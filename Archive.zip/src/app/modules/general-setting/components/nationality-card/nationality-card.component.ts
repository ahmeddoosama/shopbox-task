import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nationality-card',
  templateUrl: './nationality-card.component.html',
  styleUrls: ['./nationality-card.component.scss']
})
export class NationalityCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
