import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CitityFormComponent } from './citity-form.component';

describe('CitityFormComponent', () => {
  let component: CitityFormComponent;
  let fixture: ComponentFixture<CitityFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CitityFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CitityFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
