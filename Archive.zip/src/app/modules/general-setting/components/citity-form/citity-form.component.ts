import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citity-form',
  templateUrl: './citity-form.component.html',
  styleUrls: ['./citity-form.component.scss']
})
export class CitityFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
