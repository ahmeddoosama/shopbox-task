import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SocailCardComponent } from './socail-card.component';

describe('SocailCardComponent', () => {
  let component: SocailCardComponent;
  let fixture: ComponentFixture<SocailCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SocailCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SocailCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
