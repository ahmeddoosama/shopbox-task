import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-socail-card',
  templateUrl: './socail-card.component.html',
  styleUrls: ['./socail-card.component.scss']
})
export class SocailCardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
