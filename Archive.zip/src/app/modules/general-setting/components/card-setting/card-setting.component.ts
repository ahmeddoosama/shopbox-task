import { Component, OnInit , Input} from '@angular/core';

@Component({
  selector: 'app-card-setting',
  templateUrl: './card-setting.component.html',
  styleUrls: ['./card-setting.component.scss']
})
export class CardSettingComponent implements OnInit {

  @Input()
  get settingName(): string {
    return this._settingName;
  }
  set settingName(settingName: string) {
    this._settingName = settingName === undefined ? "Main Setting" : settingName;
  }
  private _settingName = "Main Setting";

  constructor() { }

  ngOnInit(): void {
  }

}
