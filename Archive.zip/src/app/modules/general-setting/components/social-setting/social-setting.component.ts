import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-social-setting',
  templateUrl: './social-setting.component.html',
  styleUrls: ['./social-setting.component.scss']
})
export class SocialSettingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
