import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nationality-form',
  templateUrl: './nationality-form.component.html',
  styleUrls: ['./nationality-form.component.scss']
})
export class NationalityFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
