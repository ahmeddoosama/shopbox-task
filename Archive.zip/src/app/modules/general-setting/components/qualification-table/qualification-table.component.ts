import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import {MatDialog} from '@angular/material/dialog';
import { QualificationFormComponent } from '../qualification-form/qualification-form.component';

@Component({
  selector: 'app-qualification-table',
  templateUrl: './qualification-table.component.html',
  styleUrls: ['./qualification-table.component.scss']
})
export class QualificationTableComponent implements OnInit {

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openDialog() {
    const dialogRef = this.dialog.open(QualificationFormComponent);
  }

  DeleteFn() {
    Swal.fire({
      title: '<div class="text-primary1 text-lg">Do you want to delete the product?</div>',
      showDenyButton: false,
      showCancelButton: true,
      confirmButtonColor: '#a90520',
      confirmButtonText: `Delete`,
      cancelButtonText: `Cancel`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire('<div class="size-12 weight-700 text-primary">The product has been deleted</div>','',
         'success')
      }
    })
  }

}
