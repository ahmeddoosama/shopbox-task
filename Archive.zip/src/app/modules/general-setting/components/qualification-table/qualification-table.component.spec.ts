import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QualificationTableComponent } from './qualification-table.component';

describe('QualificationTableComponent', () => {
  let component: QualificationTableComponent;
  let fixture: ComponentFixture<QualificationTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QualificationTableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QualificationTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
