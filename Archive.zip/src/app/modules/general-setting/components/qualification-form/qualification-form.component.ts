import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qualification-form',
  templateUrl: './qualification-form.component.html',
  styleUrls: ['./qualification-form.component.scss']
})
export class QualificationFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
