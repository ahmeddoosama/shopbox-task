import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BasicFormComponent } from './pages/basic-form/basic-form.component';
import { EducationComponent } from './pages/education/education.component';
import { GeneralSettingComponent } from './pages/general-setting/general-setting.component';
import { LanguagesComponent } from './pages/languages/languages.component';
import { NationalityComponent } from './pages/nationality/nationality.component';
import { PlaceOfBirthComponent } from './pages/place-of-birth/place-of-birth.component';
import { SocialSettingFormComponent } from './pages/social-setting-form/social-setting-form.component';
import { ZonesComponent } from './pages/zones/zones.component';

const routes: Routes = [
  {
    path: '',
    component: GeneralSettingComponent
  },
  {
    path: 'basic-form',
    component: BasicFormComponent
  },
  {
    path: 'social-setting',
    component: SocialSettingFormComponent
  },
  {
    path: 'place-of-birth',
    component: PlaceOfBirthComponent
  },
  {
    path: 'education',
    component: EducationComponent
  },
  {
    path: 'Nationality-form',
    component: NationalityComponent
  },
  {
    path: 'language',
    component: LanguagesComponent
  },
  {
    path: 'zones',
    component: ZonesComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GeneralSettingRoutingModule { }
