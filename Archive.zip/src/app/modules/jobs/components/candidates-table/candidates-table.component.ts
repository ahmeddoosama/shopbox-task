import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidates-table',
  templateUrl: './candidates-table.component.html',
  styleUrls: ['./candidates-table.component.scss']
})
export class CandidatesTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
