import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-candidtate-details',
  templateUrl: './candidtate-details.component.html',
  styleUrls: ['./candidtate-details.component.scss']
})
export class CandidtateDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
