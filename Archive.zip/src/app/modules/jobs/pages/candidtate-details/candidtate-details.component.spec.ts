import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CandidtateDetailsComponent } from './candidtate-details.component';

describe('CandidtateDetailsComponent', () => {
  let component: CandidtateDetailsComponent;
  let fixture: ComponentFixture<CandidtateDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CandidtateDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CandidtateDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
