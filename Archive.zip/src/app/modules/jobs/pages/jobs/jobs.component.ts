import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { JobFormComponent } from '../../components/job-form/job-form.component';

@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.scss']
})
export class JobsComponent implements OnInit {

  array = [];

  constructor(public dialog: MatDialog) {
    this.array.length = 10;
  }

  ngOnInit(): void {
  }

  openDialog() {
    const dialogRef = this.dialog.open(JobFormComponent);
  }

  onScroll() {
    console.log('scrolled!!');
    this.array.length =  this.array.length + 10;
  }
}
