import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { JobsRoutingModule } from './jobs-routing.module';
import { JobsComponent } from './pages/jobs/jobs.component';
import { JobDetailsComponent } from './pages/job-details/job-details.component';
import { SharedModule } from '../@shared/shared.module';

import {MatDialogModule} from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { JobItemComponent } from './components/job-item/job-item.component';
import { JobFormComponent } from './components/job-form/job-form.component';
import { CandidatesTableComponent } from './components/candidates-table/candidates-table.component';
import { CandidtateDetailsComponent } from './pages/candidtate-details/candidtate-details.component';


@NgModule({
  declarations: [
    JobsComponent,
    JobDetailsComponent,
    JobItemComponent,
    JobFormComponent,
    CandidatesTableComponent,
    CandidtateDetailsComponent
  ],
  imports: [
    CommonModule,
    JobsRoutingModule,
    SharedModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
    SharedModule,
    InfiniteScrollModule
  ]
})
export class JobsModule { }
