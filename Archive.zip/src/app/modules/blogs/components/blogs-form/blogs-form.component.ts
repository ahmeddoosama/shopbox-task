import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blogs-form',
  templateUrl: './blogs-form.component.html',
  styleUrls: ['./blogs-form.component.scss']
})
export class BlogsFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
