import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BlogsPageFormComponent } from './blogs-page-form.component';

describe('BlogsPageFormComponent', () => {
  let component: BlogsPageFormComponent;
  let fixture: ComponentFixture<BlogsPageFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BlogsPageFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BlogsPageFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
