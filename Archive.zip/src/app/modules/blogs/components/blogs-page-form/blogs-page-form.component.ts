import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-blogs-page-form',
  templateUrl: './blogs-page-form.component.html',
  styleUrls: ['./blogs-page-form.component.scss']
})
export class BlogsPageFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
