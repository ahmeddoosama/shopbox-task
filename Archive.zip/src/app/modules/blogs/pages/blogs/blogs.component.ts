import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { BlogsPageFormComponent } from '../../components/blogs-page-form/blogs-page-form.component';

@Component({
  selector: 'app-blogs',
  templateUrl: './blogs.component.html',
  styleUrls: ['./blogs.component.scss']
})
export class BlogsComponent implements OnInit {

  array = [];

  constructor(public dialog: MatDialog) {
    this.array.length = 10;
  }

  ngOnInit(): void {
  }

  openDialog() {
    const dialogRef = this.dialog.open(BlogsPageFormComponent);
  }

  onScroll() {
    console.log('scrolled!!');
    this.array.length =  this.array.length + 10;
  }

}
