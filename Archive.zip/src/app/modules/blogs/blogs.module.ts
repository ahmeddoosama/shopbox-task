import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BlogsRoutingModule } from './blogs-routing.module';
import { BlogsComponent } from './pages/blogs/blogs.component';
import { BlogDetailsComponent } from './pages/blog-details/blog-details.component';
import { BlogsPageFormComponent } from './components/blogs-page-form/blogs-page-form.component';
import { BlogsFormComponent } from './components/blogs-form/blogs-form.component';
import { BlogItemComponent } from './components/blog-item/blog-item.component';

import {MatDialogModule} from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { SharedModule } from '../@shared/shared.module';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

@NgModule({
  declarations: [
    BlogsComponent,
    BlogDetailsComponent,
    BlogsPageFormComponent,
    BlogsFormComponent,
    BlogItemComponent
  ],
  imports: [
    CommonModule,
    BlogsRoutingModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
    SharedModule,
    InfiniteScrollModule
  ]
})
export class BlogsModule { }
