import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SessionDetailsComponent } from './pages/session-details/session-details.component';
import { SessionsComponent } from './pages/sessions/sessions.component';

const routes: Routes = [
  {
    path: '',
    component: SessionsComponent
  },
  {
    path: 'session-details',
    component: SessionDetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SessionsRoutingModule { }
