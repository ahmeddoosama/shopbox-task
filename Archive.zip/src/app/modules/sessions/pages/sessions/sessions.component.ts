import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { EditSessionComponent } from './../../components/edit-session/edit-session.component';

@Component({
  selector: 'app-sessions',
  templateUrl: './sessions.component.html',
  styleUrls: ['./sessions.component.scss']
})
export class SessionsComponent implements OnInit {

  array = [];

  constructor(public dialog: MatDialog) {
    this.array.length = 10;
  }

  openDialog() {
    const dialogRef = this.dialog.open(EditSessionComponent);
  }

  ngOnInit(): void {
  }

  onScroll() {
    console.log('scrolled!!');
    this.array.length =  this.array.length + 10;
  }

}
