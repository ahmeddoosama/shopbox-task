import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SessionsRoutingModule } from './sessions-routing.module';
import { SessionsComponent } from './pages/sessions/sessions.component';
import { SessionDetailsComponent } from './pages/session-details/session-details.component';
import { SharedModule } from '../@shared/shared.module';
import { SessionItemComponent } from './components/session-item/session-item.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { AddImgComponent } from './components/add-img/add-img.component';

import {MatDialogModule} from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { EditSessionComponent } from './components/edit-session/edit-session.component';

@NgModule({
  declarations: [
    SessionsComponent,
    SessionDetailsComponent,
    SessionItemComponent,
    AddImgComponent,
    EditSessionComponent
  ],
  imports: [
    CommonModule,
    SessionsRoutingModule,
    SharedModule,
    InfiniteScrollModule,
    MatDialogModule,
    MatIconModule,
    MatButtonModule,
    MatSidenavModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
  ]
})
export class SessionsModule { }
