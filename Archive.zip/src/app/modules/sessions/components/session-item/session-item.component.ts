import { Component, OnInit, Input } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import Swal from 'sweetalert2';
import { EditSessionComponent } from './../edit-session/edit-session.component';
import { AddImgComponent } from './../add-img/add-img.component';

@Component({
  selector: 'app-session-item',
  templateUrl: './session-item.component.html',
  styleUrls: ['./session-item.component.scss']
})
export class SessionItemComponent implements OnInit {

  @Input()
  get proavilablety(): string {
    return this._proavilablety;
  }
  set proavilablety(proavilablety: string) {
    this._proavilablety = proavilablety === undefined ? "Available" : proavilablety;
  }
  private _proavilablety = "Available";

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {
  }

  openImg() {
    const dialogRef = this.dialog.open(AddImgComponent);
  }

  openDialog() {
    const dialogRef = this.dialog.open(EditSessionComponent);
  }

  DeleteFn() {
    Swal.fire({
      title: '<div class="text-primary1 text-lg">Do you want to delete the product?</div>',
      showDenyButton: false,
      showCancelButton: true,
      confirmButtonColor: '#a90520',
      confirmButtonText: `Delete`,
      cancelButtonText: `Cancel`,
    }).then((result) => {
      /* Read more about isConfirmed, isDenied below */
      if (result.isConfirmed) {
        Swal.fire('<div class="size-12 weight-700 text-primary">The product has been deleted</div>','',
         'success')
      }
    })
  }

}
